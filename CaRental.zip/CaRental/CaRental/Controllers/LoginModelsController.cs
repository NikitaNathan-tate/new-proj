﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CaRental.Models;
using Microsoft.AspNetCore.Authorization;

namespace CaRental.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    
    public class LoginModelsController : ControllerBase
    {
        private readonly IdentityContext _context;

        public LoginModelsController(IdentityContext context)
        {
            _context = context;
        }

        // GET: api/LoginModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LoginModels>>> GetloginModels()
        {
            return await _context.loginModels.ToListAsync();
        }

        // GET: api/LoginModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LoginModels>> GetLoginModels(int id)
        {
            var loginModels = await _context.loginModels.FindAsync(id);

            if (loginModels == null)
            {
                return NotFound();
            }

            return loginModels;
        }

        // PUT: api/LoginModels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLoginModels(int id, LoginModels loginModels)
        {
            if (id != loginModels.id)
            {
                return BadRequest();
            }

            _context.Entry(loginModels).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LoginModelsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/LoginModels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<LoginModels>> PostLoginModels(LoginModels loginModels)
        {
            _context.loginModels.Add(loginModels);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLoginModels", new { id = loginModels.id }, loginModels);
        }

        // DELETE: api/LoginModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<LoginModels>> DeleteLoginModels(int id)
        {
            var loginModels = await _context.loginModels.FindAsync(id);
            if (loginModels == null)
            {
                return NotFound();
            }

            _context.loginModels.Remove(loginModels);
            await _context.SaveChangesAsync();

            return loginModels;
        }

        private bool LoginModelsExists(int id)
        {
            return _context.loginModels.Any(e => e.id == id);
        }
    }
}
