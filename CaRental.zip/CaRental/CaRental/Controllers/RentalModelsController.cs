﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CaRental.Models;

namespace CaRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RentalModelsController : ControllerBase
    {
        private readonly IdentityContext _context;

        public RentalModelsController(IdentityContext context)
        {
            _context = context;
        }

        // GET: api/RentalModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RentalModels>>> GetRental()
        {
            return await _context.Rental.ToListAsync();
        }

        // GET: api/RentalModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RentalModels>> GetRentalModels(int id)
        {
            var rentalModels = await _context.Rental.FindAsync(id);

            if (rentalModels == null)
            {
                return NotFound();
            }

            return rentalModels;
        }

        // PUT: api/RentalModels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRentalModels(int id, RentalModels rentalModels)
        {
            if (id != rentalModels.IdRental)
            {
                return BadRequest();
            }

            _context.Entry(rentalModels).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RentalModelsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RentalModels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<RentalModels>> PostRentalModels(RentalModels rentalModels)
        {
            _context.Rental.Add(rentalModels);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRentalModels", new { id = rentalModels.IdRental }, rentalModels);
        }

        // DELETE: api/RentalModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<RentalModels>> DeleteRentalModels(int id)
        {
            var rentalModels = await _context.Rental.FindAsync(id);
            if (rentalModels == null)
            {
                return NotFound();
            }

            _context.Rental.Remove(rentalModels);
            await _context.SaveChangesAsync();

            return rentalModels;
        }

        private bool RentalModelsExists(int id)
        {
            return _context.Rental.Any(e => e.IdRental == id);
        }
    }
}
