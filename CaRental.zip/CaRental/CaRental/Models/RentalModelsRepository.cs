﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public class RentalModelsRepository : IRentalModelsRepository
    {
        private readonly IdentityContext _appDbContext;

        public RentalModelsRepository(IdentityContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<RentalModels> AllCategories => _appDbContext.Rental;

    }
}
