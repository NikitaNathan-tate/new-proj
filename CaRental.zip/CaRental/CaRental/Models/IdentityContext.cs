﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaRental.Models;

namespace CaRental.Models
{
    public class IdentityContext : DbContext
    {
        public IdentityContext(DbContextOptions<IdentityContext> options) : base(options)
        {
        }

        public DbSet<CarModels> Car { get; set; }
        public DbSet<RentalModels> Rental { get; set; }

        public DbSet<LoginModels> loginModels { get; set; }
        public DbSet<PersonModels> Person { get; set; }
        public DbSet<CategoryModels> CategoryModels { get; set; }
        //public IEnumerable<object> CarModels { get; internal set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //seed login
            modelBuilder.Entity< LoginModels>().HasData(new LoginModels
            {
               id = 1,
               UserName = "nik",
               Email="nikitayaduvansh@gmail.com",
               Password = "nikita"

            });

            modelBuilder.Entity<LoginModels>().HasData(new LoginModels
            {
                id = 2,
                UserName = "nikk",
                Email = "nikitayaduvanshi@gmail.com",
                Password = "nikKita"

            });
            //seed carcategory

            modelBuilder.Entity<CategoryModels>().HasData(new CategoryModels { IdCategory = 1, CategoryName = "Sedan" });
            modelBuilder.Entity<CategoryModels>().HasData(new CategoryModels { IdCategory = 2, CategoryName = "Hatchback" });


            //seed CarModels

            modelBuilder.Entity<CarModels>().HasData(new CarModels
            {
                IdCar = 1,
                Brand = "Audi",
                Model = "Audi Q7",
                Description = "hehehehehe",
                Km = 20,
                IdCategory = 1


            });
            modelBuilder.Entity<CarModels>().HasData(new CarModels
            {
                IdCar = 2,
                Brand = "Audi",
                Model = "Audi Q4",
                Description = "huhuhu",
                Km = 20,
                IdCategory = 1

                
            });

            modelBuilder.Entity<CarModels>().HasData(new CarModels
            {
                IdCar = 3,
                Brand = "Audi A3",
                Model = "Audi Q7",
                Description = "hahahaha",
                Km = 30,
                IdCategory = 2


            });

            modelBuilder.Entity<CarModels>().HasData(new CarModels
            {
                IdCar = 4,
                Brand = "Audi A4",
                Model = "Audi Q7",
                Description = "hihihi",
                Km = 30,
                IdCategory = 1


            });


        }

     


       
             



        


    }
}

