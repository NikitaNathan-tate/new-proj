﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace CaRental.Models
{
   
        public class ClassModelsRepository : ICarModelsRepository
        {
            private readonly IdentityContext _appDbContext;

            public ClassModelsRepository(IdentityContext appDbContext)
            {
                _appDbContext = appDbContext;
            }

       
        public IEnumerable<CarModels> AllCar => _appDbContext.Car;


    }

}

