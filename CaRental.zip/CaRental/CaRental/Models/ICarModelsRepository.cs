﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public class ICarModelsRepository
    {
      public IEnumerable<CarModels> AllCar { get; }
       
    }
}
