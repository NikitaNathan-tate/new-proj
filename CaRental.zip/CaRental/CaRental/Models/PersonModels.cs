﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public class PersonModels
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdPerson { get; set; }

       
        public string Email { get; set; }

        
        public string Name { get; set; }

       
        public string Nickname { get; set; }

        
        public string Driving_habits { get; set; }

       
        public string Driver_experience { get; set; }

       
         public virtual IdentityContext User { get; set; }
         public string IdentityContextId { get; set; }


    }
}
